using Microsoft.EntityFrameworkCore;
using TaskManagerApi.Models;

namespace TaskManagerApi.Data
{
    // AppDbContext is the bridge between your C# classes (models)
    // and the SQLite database. EF Core uses this to query and save data.
    public class AppDbContext : DbContext
    {
        // Constructor: EF Core will inject options (like SQLite connection string)
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        // DbSet represents a table in the database.
        // Here, "TaskItems" will map to a SQLite table named TaskItems.
        public DbSet<TaskItem> TaskItems { get; set; } = null!;
    }
}
