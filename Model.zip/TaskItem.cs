namespace TaskManagerApi.Models
{
    // Represents a single task in the system
    public class TaskItem
    {
        // Primary key (auto-incremented by EF Core when using SQLite)
        public int Id { get; set; }

        // Short title or name of the task
        public string Title { get; set; } = string.Empty;

        // Optional longer description of the task
        public string? Description { get; set; }

        // Flag to mark whether the task is completed
        public bool IsComplete { get; set; }

        // Optional due date for the task
        public DateTime? DueDate { get; set; }

        // Optional priority level (e.g., 1 = High, 2 = Medium, 3 = Low)
        public int Priority { get; set; } = 2; // default Medium
    }
}
