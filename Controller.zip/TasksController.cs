using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskManagerApi.Data;
using TaskManagerApi.Models;

namespace TaskManagerApi.Controllers
{
    // Marks this class as an API controller
    // Route will be: /api/tasks
    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : ControllerBase
    {
        private readonly AppDbContext _context;

        // Constructor: EF Core DbContext is injected here
        public TasksController(AppDbContext context)
        {
            _context = context;
        }

        // -------------------- CRUD ENDPOINTS --------------------

        // GET: /api/tasks
        // Returns all tasks in the database
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TaskItem>>> GetAll()
        {
            return await _context.TaskItems.ToListAsync();
        }

        // GET: /api/tasks/{id}
        // Returns a single task by ID
        [HttpGet("{id}")]
        public async Task<ActionResult<TaskItem>> GetById(int id)
        {
            var task = await _context.TaskItems.FindAsync(id);
            if (task == null) return NotFound();
            return task;
        }

        // POST: /api/tasks
        // Creates a new task
        [HttpPost]
        public async Task<ActionResult<TaskItem>> Create(TaskItem task)
        {
            _context.TaskItems.Add(task);
            await _context.SaveChangesAsync();

            // Returns 201 Created with the new task’s location
            return CreatedAtAction(nameof(GetById), new { id = task.Id }, task);
        }

        // PUT: /api/tasks/{id}
        // Updates an existing task
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, TaskItem task)
        {
            if (id != task.Id) return BadRequest();

            _context.Entry(task).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent(); // 204 No Content
        }

        // DELETE: /api/tasks/{id}
        // Deletes a task by ID
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var task = await _context.TaskItems.FindAsync(id);
            if (task == null) return NotFound();

            _context.TaskItems.Remove(task);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
